package field;

/**
 * Created by Plein on 30/11/2016.
 */
public enum Element {
    BUG
}
